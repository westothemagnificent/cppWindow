#include "SDL.h"
#include "SDL_ttf.h"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <windows.h>

#pragma once  // If supported by compiler

int WARNING = 2;
int ERRORS = 3;
int NOTE = 1;
int ALL = 0;
int NONE = -1;

class {

    public:
        bool debug = false;

        int level = ALL;

        template <typename T>
        void writeLine(T str, int errorLevel){
            if(debug && (errorLevel == level || level == ALL)){
                std::cout << str << "\n";
            }
        }

}debuger;

class trect
{
    public:
        double x;
        double y;
        double w;
        double h;

        trect(double X, double Y, double W, double H){
            x = X;
            y = Y;
            w = W;
            h = H;
        }

        SDL_Rect trectToSDLrect(){
            SDL_Rect r;
            r.x = x;
            r.y = y;
            r.w = w;
            r.h = h;
            return r;
        }

};

struct Asset {
    SDL_Texture * texture;
};

class sprite {
    public:
        std::shared_ptr<Asset> asset;

        trect sprite_rec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;
        
        sprite(trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a){
            sprite_rec = rec;
            name = Name;
            tag = Tag;
            layer = Layer;
            asset = a;
        }

        void push(std::vector<sprite*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }


    private:
        std::vector<sprite*> * vector = nullptr;

};

class button {
    public:

        sprite buttonSprite = sprite(trect(0,0,0,0), "NULL", "NULL", -1, nullptr);

        trect buttonRec = trect(0,0,0,0);
        // 0 no state, 1 pressed, 2 hovered
        int state = 0;
        int toggle = 0;
        void (*callBack)(int, button *);

        button(void (*fp)(int, button *), trect buttonRecF, trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a){
            callBack = fp;
            buttonRec = buttonRecF;
            buttonSprite.sprite_rec = rec;
            buttonSprite.name = Name;
            buttonSprite.tag = Tag;
            buttonSprite.layer = Layer;
            buttonSprite.asset = a;
        }

        void handle(SDL_Event e, int mouseX, int mouseY){
            
            if((e.type == SDL_MOUSEBUTTONDOWN) && (((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 1;
            }
            else if((((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 2;
            }
            else{
                state = 0;
            }
            callBack(state, this);
    
        }

        void push(std::vector<button*> * vec, std::vector<sprite*> * spriteVec){
            vec->push_back(this);
            buttonSprite.push(spriteVec);
            vector = vec;
        }

    private:
        std::vector<button*> * vector = nullptr;

};

class text{
    public:
        
        SDL_Texture * textTex;
        std::string textStringValue;

        trect sprite_rec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;

        text(trect rec, std::string Name, std::string Tag, int Layer, const char * str, SDL_Color rgb, TTF_Font * font, SDL_Renderer * ren){
            if(!font)
            {
                debuger.writeLine("(!)-- Failed to load font\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_Surface* image = TTF_RenderText_Solid(font, str, rgb);
            if(!image)
            {
                debuger.writeLine("(!)-- Failed to load image\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);;
                std::terminate();
            }
            textTex = SDL_CreateTextureFromSurface(ren, image);
            if(!textTex){
                debuger.writeLine("(!)-- SDL_CreateTextureFromSurface has failed cuased by bad args", ERRORS);
                std::terminate();
            }
            sprite_rec = rec;
            name = Name;
            tag = Tag;
            layer = Layer;
            textStringValue = str;
        }
        void push(std::vector<text*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }
    private:
        std::vector<text*> * vector = nullptr;
};

// define all assets here like this: std::shared_ptr<Asset> ex;
//v
struct Assets {
    std::shared_ptr<Asset> apple;
};

Assets gAssets;

class WIN {
    public:
        SDL_Window * SDLWindow;
        SDL_Renderer * ren;

        std::vector<sprite*> spritePointers = {};
        std::vector<text*> textPointers = {};

        std::vector<button*> buttonPointers = {};

        int camx = 0;
        int camy = 0;

        // editing this will cuase sprite using these to change positions
        int CENTERX;
        // editing this will cuase sprite using these to change positions
        int CENTERY;

        // do NOT change after calling open window
        int width;
        // do NOT change after calling open window
        int height;

        int mouseX;
        int mouseY;

        // window stuff
        void open_window(const char * name) {
            if (SDL_Init(SDL_INIT_EVERYTHING)) {
                debuger.writeLine("(!)-- Failed to initialize the SDL2 library\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: \n" + std::string(SDL_GetError()), ERRORS);
                std::terminate();
            }
            SDL_Window * windowSDL = SDL_CreateWindow(
                name,
                SDL_WINDOWPOS_CENTERED,
                SDL_WINDOWPOS_CENTERED,
                width,
                height,
                SDL_WINDOW_ALWAYS_ON_TOP
                //SDL_WINDOW_RESIZABLE
            );
            CENTERX = width / 2;
            CENTERY = height / 2;
            SDLWindow = windowSDL;
            SDL_SetWindowFullscreen(windowSDL, SDL_WINDOW_FULLSCREEN_DESKTOP);
            ren = SDL_CreateRenderer(SDLWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
            SDL_SetHint("SDL_HINT_RENDER_SCALE_QUALITY", "linear");
            SDL_RenderSetLogicalSize(ren, width, height);
            SDL_RaiseWindow(SDLWindow);
            SDL_SetWindowInputFocus(SDLWindow);
        }
        
        //drawing

        void render_sprite(sprite sprite, int index) {
            if (nullptr != sprite.asset) {
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();
                debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopy(ren, sprite.asset->texture, NULL, &rec))), NOTE);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(spritePointers[index]->asset->texture);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTE);

                spritePointers.erase(spritePointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNING);
            }
        }

        void render_text(text sprite, int index) {
            if (nullptr != sprite.textTex) {
                if (sprite.tag == "ui") {
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2));
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2));
                }
                else{
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2)+camx);
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2)+camy);
                }
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();
                debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopy(ren, sprite.textTex, NULL, &rec))), NOTE);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(textPointers[index]->textTex);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTE);

                textPointers.erase(textPointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNING);
            }
        }

        void renderAllSprites() {
            for (size_t i = 0; i < spritePointers.size(); i++) {
                render_sprite(*spritePointers[i], i);
            }
            for (size_t i = 0; i < textPointers.size(); i++) {
                render_text(*textPointers[i], i);
            }
        }

        // do NOT set rgb value over 255
        void setBg(int r, int g, int b){
            SDL_SetRenderDrawColor(ren, r, g, b, 255);
        }

        void renClear(){
            SDL_RenderClear(ren);
        }

        void show(){
            SDL_RenderPresent(ren);
        }

        // event handling

        bool checkIfUserExitThenExit(SDL_Event e, void (*callBack)()) {
            bool r = true;
            switch (e.type) {
                case SDL_QUIT:
                    debuger.writeLine("(*)-- SDL closed", NOTE);
                    callBack();
                    r = false;
                    break;
            }
            return r;
        }

        void handleButtons(SDL_Event e){
            SDL_GetMouseState(&mouseX,&mouseY);
            for(int i=0; i < buttonPointers.size(); i++){
                buttonPointers[i]->handle(e,mouseX,mouseY);
            }
        }

        // file stuff

        std::shared_ptr<Asset> load_asset(const char * file) {
            std::shared_ptr<Asset> asset = std::make_shared<Asset>();

            SDL_Surface * suf = SDL_LoadBMP(file);

            if (!suf) {
                debuger.writeLine("(!)-- Failed to load file: " + std::string(file) + "\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }

            asset->texture = SDL_CreateTextureFromSurface(ren, suf);

            if (!asset->texture) {
                debuger.writeLine("(!)-- Failed to make texture\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_FreeSurface(suf);

            return asset;
        }

        //gAssets.ex = load_asset("art/ex.bmp"); load all of your assets here
        //v
        void load_assets() {
            gAssets.apple = load_asset("art/apple.bmp");
        }
};