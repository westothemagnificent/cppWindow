#include "SDLWINDOW.hpp"
#include <iostream>
#include <string>
#include <vector>

WIN window;

std::vector<sprite*> sprites = {};
std::vector<text*> texts = {};

std::vector<button*> buttons = {};

int ballSpeedX = 2;
int ballSpeedY = 1;

int r = 100;
int g = 200;
int b = 100;

void closed(){
    system("start game.exe");
}

void tickBall(){
    sprites[0]->sprite_rec.x += ballSpeedX;
    sprites[0]->sprite_rec.y += ballSpeedY;
    if(sprites[0]->sprite_rec.x > window.width){
        sprites[0]->sprite_rec.x = window.width;
        ballSpeedX = 0 - ballSpeedX;
        r = rand() % 255;
        g = rand() % 255;
        b = rand() % 255;
    }
    if(sprites[0]->sprite_rec.x < 0){
        sprites[0]->sprite_rec.x = 0;
        ballSpeedX = 0 - ballSpeedX;
        r = rand() % 255;
        g = rand() % 255;
        b = rand() % 255;
    }
    if(sprites[0]->sprite_rec.y < 0){
        sprites[0]->sprite_rec.y = 0;
        ballSpeedY = 0 - ballSpeedY;
        r = rand() % 255;
        g = rand() % 255;
        b = rand() % 255;
    }
    if(sprites[0]->sprite_rec.y > window.height){
        sprites[0]->sprite_rec.y = window.height;
        ballSpeedY = 0 - ballSpeedY;
        r = rand() % 255;
        g = rand() % 255;
        b = rand() % 255;
    }
}

void start(){

    window.width = 1000;
    window.height = 700;
    window.open_window("some window");

    
    window.load_assets();
    if (TTF_Init() < 0) {
	    std::cout << "Error initializing SDL_ttf: " << TTF_GetError() << "\n";
    }
    TTF_Font* Sans = TTF_OpenFont("fonts/static/OpenSans-Medium.ttf", 24);
    SDL_Event event;


    // buttons.push_back(new button(&pressed, trect(window.CENTERX,window.CENTERY,25,25), trect(window.CENTERX, window.CENTERY, 100,100), "button", "idk", 1, gAssets.apple));
    // buttons[buttons.size()-1]->push(&window.buttonPointers, &window.spritePointers);

    texts.push_back(new text(trect(window.CENTERX,window.CENTERY,300,100), "text", "ui", 1, "hello, this a screen saver",  {255,255,255}, Sans, window.ren));
    texts[texts.size()-1]->push(&window.textPointers);

    sprites.push_back(new sprite(trect(window.CENTERX, window.CENTERY,40,40), "ball", "gameObject", 1, gAssets.apple));
    sprites[sprites.size()-1]->push(&window.spritePointers);

    debuger.debug = true;
    debuger.level = ALL;

    bool isWindowOpen = true;

    int timer = 0;

    while (isWindowOpen){
        
        // clear

        SDL_ShowCursor(SDL_DISABLE);
        window.renClear();

        // window exit?

        SDL_PollEvent(&event);
        isWindowOpen = window.checkIfUserExitThenExit(event, &closed);

        // handle events

        window.handleButtons(event);

        tickBall();

        // draw
        window.setBg(r,g,b);
        
        window.renderAllSprites();

        //show
        window.show();

        if(timer > 5000){
            for(int i=0; i<texts.size(); i++){
                texts[i]->deleteSprite();
            }
        }
        timer ++;
    }

    std::cout << " exited!\n";

}

bool keyBoardPressed(){
    bool pressed = false;
if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) { //ESC
    pressed = true;
} else if (GetAsyncKeyState(VK_F1) & 0x8000) { //F1
    pressed = true;
}
else if (GetAsyncKeyState(VK_F2) & 0x8000) { //F2
    pressed = true;
}
else if (GetAsyncKeyState(VK_F3) & 0x8000) { //F3
    pressed = true;
}
else if (GetAsyncKeyState(VK_F4) & 0x8000) { //F4
    pressed = true;
}
else if (GetAsyncKeyState(VK_F5) & 0x8000) { //F5
    pressed = true;
}
else if (GetAsyncKeyState(VK_F6) & 0x8000) { //F6
    pressed = true;
}
else if (GetAsyncKeyState(VK_F7) & 0x8000) { //F7
    pressed = true;
}
else if (GetAsyncKeyState(VK_F8) & 0x8000) { //F8
    pressed = true;
}
else if (GetAsyncKeyState(VK_F9) & 0x8000) { //F9
    pressed = true;
}
else if (GetAsyncKeyState(VK_F10) & 0x8000) { //F10
    pressed = true;
}
else if (GetAsyncKeyState(VK_F11) & 0x8000) { //F11
    pressed = true;
}
else if (GetAsyncKeyState(VK_F12) & 0x8000) { //F12
    pressed = true;
}
else if (GetAsyncKeyState(VK_TAB) & 0x8000) { //TAB
    pressed = true;
}
else if (GetAsyncKeyState(VK_CAPITAL) & 0x8000) { //CAPS
    pressed = true;
}
else if (GetAsyncKeyState(VK_SHIFT) & 0x8000) { //SHIFT
    pressed = true;
}
else if (GetAsyncKeyState(VK_CONTROL) & 0x8000) { //CONTROL
    pressed = true;
}
else if (GetAsyncKeyState(VK_MENU) & 0x8000) { //ALT
    pressed = true;
}
else if (GetAsyncKeyState(VK_RCONTROL) & 0x8000) { //RIGHT CONTROL
    pressed = true;
}
else if (GetAsyncKeyState(VK_RSHIFT) & 0x8000) { //RIGHT SHIFT
    pressed = true;
}
else if (GetAsyncKeyState(VK_SPACE) & 0x8000) { //VK_SPACE
    pressed = true;
}
else if (GetAsyncKeyState(VK_PRIOR) & 0x8000) { //PAGE UP key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NEXT) & 0x8000) { //PAGE DOWN key
    pressed = true;
}
else if (GetAsyncKeyState(VK_END) & 0x8000) { //END key
    pressed = true;
}
else if (GetAsyncKeyState(VK_HOME) & 0x8000) { //HOME key
    pressed = true;
}
else if (GetAsyncKeyState(VK_LEFT) & 0x8000) { //LEFT ARROW key
    pressed = true;
}
else if (GetAsyncKeyState(VK_UP) & 0x8000) { //UP ARROW key
    pressed = true;
}
else if (GetAsyncKeyState(VK_RIGHT) & 0x8000) { //RIGHT ARROW key
    pressed = true;
}
else if (GetAsyncKeyState(VK_DOWN) & 0x8000) { //DOWN ARROW key
    pressed = true;
}
else if (GetAsyncKeyState(VK_INSERT) & 0x8000) { //INS key
    pressed = true;
}
else if (GetAsyncKeyState(VK_DELETE) & 0x8000) { //DEL key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD0) & 0x8000) { //Numeric keypad 0 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD1) & 0x8000) { //Numeric keypad 1 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD2) & 0x8000) { //Numeric keypad 2 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD3) & 0x8000) {//Numeric keypad 3 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD4) & 0x8000) { //Numeric keypad 4 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD5) & 0x8000) { //Numeric keypad 5 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD6) & 0x8000) { //Numeric keypad 6 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD7) & 0x8000) { //Numeric keypad 7 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD8) & 0x8000) {//Numeric keypad 8 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMPAD9) & 0x8000) { //Numeric keypad 9 key
    pressed = true;
}
else if (GetAsyncKeyState(VK_MULTIPLY) & 0x8000) { //VK_MULTIPLY
    pressed = true;
}
else if (GetAsyncKeyState(VK_ADD) & 0x8000) { //Add key
    pressed = true;
}
else if (GetAsyncKeyState(VK_SEPARATOR) & 0x8000) { //Separator key
    pressed = true;
}
else if (GetAsyncKeyState(VK_SUBTRACT) & 0x8000) { //Subtract key
    pressed = true;
}
else if (GetAsyncKeyState(VK_DECIMAL) & 0x8000) { //Decimal key
    pressed = true;
}
else if (GetAsyncKeyState(VK_DIVIDE) & 0x8000) { //VK_DIVIDE
    pressed = true;
}
else if (GetAsyncKeyState(VK_NUMLOCK) & 0x8000) { //NUM LOCK key
    pressed = true;
}
else if (GetAsyncKeyState(VK_SCROLL) & 0x8000) { //SCROLL LOCK key
    pressed = true;
}
else if (GetAsyncKeyState(VK_OEM_PLUS)

 & 0x8000) { //For any country/region, the '+' key
    pressed = true;
}
else if (GetAsyncKeyState(VK_OEM_COMMA) & 0x8000) { //For any country/region, the ',' key
    pressed = true;
}
else if (GetAsyncKeyState(VK_OEM_MINUS) & 0x8000) { //For any country/region, the '-' key
    pressed = true;
}
else if (GetAsyncKeyState(VK_OEM_PERIOD) & 0x8000) { //For any country/region, the '.' key
    pressed = true;
}
else if (GetAsyncKeyState('Q') & 0x8000) { //if key q is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('W') & 0x8000) { //if key w is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('E') & 0x8000) { //if key e is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('R') & 0x8000) { //if key r is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('T') & 0x8000) { //if key t is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('Y') & 0x8000) { //if key y is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('U') & 0x8000) { //if key u is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('I') & 0x8000) { //if key i is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('O') & 0x8000) { //if key o is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('P') & 0x8000) { //if key p is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('A') & 0x8000) { //if key a is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('S') & 0x8000) { //if key s is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('D') & 0x8000) { //if key d is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('F') & 0x8000) { //if key f is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('G') & 0x8000) { //if key g is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('H') & 0x8000) { //if key h is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('J') & 0x8000) { //if key j is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('K') & 0x8000) { //if key k is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('L') & 0x8000) { //if key l is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('Z') & 0x8000) { //if key z is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('X') & 0x8000) { //if key x is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('C') & 0x8000) { //if key c is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('V') & 0x8000) { //if key v is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('B') & 0x8000) { //if key b is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('N') & 0x8000) { //if key n is pressed.
    pressed = true;
}
else if (GetAsyncKeyState('M') & 0x8000) { //if key m is pressed.
    pressed = true;
}
else if(GetAsyncKeyState(MK_LBUTTON) & 0x8000){
    pressed = true;
}
else if(GetAsyncKeyState(MK_RBUTTON) & 0x8000){
    pressed = true;
}
else if(GetAsyncKeyState(WM_MOUSEMOVE) & 0x8000){
    pressed = true;
}
return pressed;
}


int main(int argc, char ** argv){
    int timer = 0;    
    while (timer < 50000)
    {
        WPARAM wParam;
        if(keyBoardPressed()){
            timer = 0;
        }
        timer ++;


    }

    start();
        

    return 0;
}