#include "SDL.h"
#include "SDL_ttf.h"
#include "class.hpp"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <windows.h>
#include <functional>
#include <optional>

#pragma once  // If supported by compiler


class WIN {
    public:
        SDL_Window * SDLWindow;
        SDL_Renderer * ren;

        std::vector<sprite*> spritePointers = {};
        std::vector<text*> textPointers = {};

        std::vector<button*> buttonPointers = {};

        std::vector<script*> scriptPointers = {};
        std::vector<gameObject*> gameObjectPointers = {};

        int camx = 0;
        int camy = 0;

        // editing this will cuase sprite using these to change positions
        int CENTERX;
        // editing this will cuase sprite using these to change positions
        int CENTERY;

        // do NOT change after calling open window
        int width;
        // do NOT change after calling open window
        int height;

        int mouseX;
        int mouseY;

        // window stuff
        void open_window(const char * name) {
            if (SDL_Init(SDL_INIT_EVERYTHING)) {
                debuger.writeLine("(!)-- Failed to initialize the SDL2 library\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: \n" + std::string(SDL_GetError()), ERRORS);
                std::terminate();
            }
            SDL_Window * windowSDL = SDL_CreateWindow(
                name,
                SDL_WINDOWPOS_CENTERED,
                SDL_WINDOWPOS_CENTERED,
                width,
                height,
                //SDL_WINDOW_ALWAYS_ON_TOP
                SDL_WINDOW_RESIZABLE
            );
            CENTERX = width / 2;
            CENTERY = height / 2;
            SDLWindow = windowSDL;
            ren = SDL_CreateRenderer(SDLWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
            SDL_SetHint("SDL_HINT_RENDER_SCALE_QUALITY", "linear");
            SDL_RenderSetLogicalSize(ren, width, height);
            SDL_RaiseWindow(SDLWindow);
            SDL_SetWindowInputFocus(SDLWindow);
        }
        void setFullScreen(){
            SDL_SetWindowFullscreen(SDLWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
        }
        void resizeWindow(SDL_Window * window, int w, int h){
            width = w;
            height = h;
            CENTERX = width / 2;
            CENTERY = height / 2;
            SDL_SetWindowSize(window, w, h);
        }
        
        //drawing

        void render_sprite(sprite sprite, int index) {
            if (sprite.tag == "ui") {
                sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2));
                sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2));
            }
            else{
                sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2)+camx);
                sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2)+camy);
            }
            if (nullptr != sprite.asset) {
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();
                debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopy(ren, sprite.asset->texture, NULL, &rec))), NOTE);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(spritePointers[index]->asset->texture);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTE);

                spritePointers.erase(spritePointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNING);
            }
        }

        void render_text(text sprite, int index) {
            if (nullptr != sprite.textTex) {
                if (sprite.tag == "ui") {
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2));
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2));
                }
                else{
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2)+camx);
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2)+camy);
                }
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();
                debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopy(ren, sprite.textTex, NULL, &rec))), NOTE);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(textPointers[index]->textTex);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTE);

                textPointers.erase(textPointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNING);
            }
        }

        void resetLayers(){
            
        }

        void renderAllSprites() {
            // std::vector<layer> vecL = {};

            for (size_t i = 0; i < spritePointers.size(); i++) {
                render_sprite(*spritePointers[i], i);
                //vecL.push_back(layer(spritePointers[i]->layer, spritePointers[i]->asset->texture));

            }
            
            for (size_t i = 0; i < textPointers.size(); i++) {
                render_text(*textPointers[i], i);
            }
        }

        // do NOT set rgb value over 255
        void setBg(int r, int g, int b){
            SDL_SetRenderDrawColor(ren, r, g, b, 255);
        }

        void renClear(){
            SDL_RenderClear(ren);
        }

        void show(){
            SDL_RenderPresent(ren);
        }

        // event handling

        bool checkIfUserExitThenExit(SDL_Event e, void (*callBack)()) {
            bool r = true;
            switch (e.type) {
                case SDL_QUIT:
                    debuger.writeLine("(*)-- SDL closed", NOTE);
                    callBack();
                    r = false;
                    break;
            }
            return r;
        }

        void handleEvents(SDL_Event e){
            SDL_GetMouseState(&mouseX,&mouseY);
            for(int i=0; i < buttonPointers.size(); i++){
                buttonPointers[i]->handle(e,mouseX,mouseY);
            }
            for(int i=0; i < scriptPointers.size(); i++){
                scriptPointers[i]->update();
            }
        }

        // searching functions

        template <typename T>
        
        std::vector<T*> findGameObject(std::string name){
            std::vector<T*> vec = {};
            for (size_t i = 0; i < gameObjectPointers.size(); i++)
            {
                if(gameObjectPointers[i]->name == name){
                    
                    T * r = dynamic_cast<T*>(gameObjectPointers[i]);
                    if(r == nullptr){
                        debuger.writeLine("(!)-- could not cast", ERRORS);
                        std::terminate();
                    }
                    else{
                        vec.push_back(r);
                    }
                }
            }

            if(vec.size() == 0){
                debuger.writeLine("(!?)-- could not find game object", WARNING);
            }

            return vec;
            
        }

        // file stuff

        std::shared_ptr<Asset> load_asset(const char * file) {
            std::shared_ptr<Asset> asset = std::make_shared<Asset>();

            SDL_Surface * suf = SDL_LoadBMP(file);

            if (!suf) {
                debuger.writeLine("(!)-- Failed to load file: " + std::string(file) + "\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }

            asset->texture = SDL_CreateTextureFromSurface(ren, suf);

            if (!asset->texture) {
                debuger.writeLine("(!)-- Failed to make texture\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_FreeSurface(suf);

            return asset;
        }

        //gAssets.ex = load_asset("art/ex.bmp"); load all of your assets here
        //v
        void load_assets() {
            gAssets.apple = load_asset("art/apple.bmp");
            gAssets.belt = load_asset("art/card_back.bmp");
        }
};