#include "SDL.h"
#include "SDL_ttf.h"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <windows.h>
#include <functional>
#include "Point.hpp"

int WARNING = 2;
int ERRORS = 3;
int NOTE = 1;
int ALL = 0;
int NONE = -1;

class trect
{
    public:
        double x;
        double y;
        double w;
        double h;

        trect(double X, double Y, double W, double H){
            x = X;
            y = Y;
            w = W;
            h = H;
        }


        SDL_Rect trectToSDLrect(){
            SDL_Rect r;
            r.x = x;
            r.y = y;
            r.w = w;
            r.h = h;
            return r;
        }

};


class {

    public:
        bool debug = false;

        int level = ALL;

        template <typename T>
        void writeLine(T str, int errorLevel){
            if(debug && (errorLevel == level || level == ALL)){
                std::cout << str << "\r\n";
            }
        }

}debuger;

class script{
    public:

        void push(std::vector<script*> * vec){
            vec->push_back(this);

            start();
        }
        virtual void start(){
                
        }

        virtual void update(){
            
        }
};

class gameObject : public script{
    public:
        std::string name;
        std::string tag;

        trect gameObjectRec = trect(0,0,0,0);

        std::vector<trect*> boundRecs = {};

        void bindRec(trect * rec){
            boundRecs.push_back(rec);
        }

        void tickAllBoundRecs(){
            for (int i = 0; i < boundRecs.size(); i++){
                
                boundRecs[i]->x = gameObjectRec.x; 
                boundRecs[i]->y = gameObjectRec.y;

            }
            
        }


        void pushGameObject(std::vector<gameObject*> * vec){
            vec->push_back(this);
        }

};


class collider{
    
    public:
        
        trect rec = trect(0,0,0,0);
        bool sleeping = false;

        collider(trect recF, bool isSleeping){
            rec = recF;
            sleeping = isSleeping;
        }

        void pushCollider(std::vector<collider*> * vec){
            vec->push_back(this);
        }

};


struct Asset {
    SDL_Texture * texture;
};

class sprite {
    public:
        std::shared_ptr<Asset> asset;

        trect sprite_rec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;
        
        sprite(trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a){
            sprite_rec = rec;
            name = Name;
            tag = Tag;
            layer = Layer;
            asset = a;
        }

        void push(std::vector<sprite*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }


    private:
        std::vector<sprite*> * vector = nullptr;

};

class button {
    public:

        sprite buttonSprite = sprite(trect(0,0,0,0), "NULL", "NULL", -1, nullptr);

        trect buttonRec = trect(0,0,0,0);
        // 0 no state, 1 pressed, 2 hovered
        int state = 0;
        int toggle = 0;
        std::function<void(int, int, button*)> callBack;

        button(std::function<void(int, int, button*)> fp, trect buttonRecF, trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a) : callBack(fp){
            callBack = fp;
            buttonRec = buttonRecF;
            buttonSprite.sprite_rec = rec;
            buttonSprite.name = Name;
            buttonSprite.tag = Tag;
            buttonSprite.layer = Layer;
            buttonSprite.asset = a;
        }

        void handle(SDL_Event e, int mouseX, int mouseY){
            
            if((e.type == SDL_MOUSEBUTTONDOWN) && (((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 1;
                if(toggle == 0){
                    toggle = 1;
                }
                else{
                    toggle = 0;
                }
            }
            else if((((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 2;
            }
            else{
                state = 0;
            }
            callBack(state, toggle, this);
    
        }

        void push(std::vector<button*> * vec, std::vector<sprite*> * spriteVec){
            vec->push_back(this);
            buttonSprite.push(spriteVec);
            vector = vec;
        }

    private:
        std::vector<button*> * vector = nullptr;

};

class text{
    public:
        
        SDL_Texture * textTex;
        std::string textStringValue;

        trect sprite_rec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;

        text(trect rec, std::string Name, std::string Tag, int Layer, const char * str, SDL_Color rgb, TTF_Font * font, SDL_Renderer * ren){
            if(!font)
            {
                debuger.writeLine("(!)-- Failed to load font\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_Surface* image = TTF_RenderText_Solid(font, str, rgb);
            if(!image)
            {
                debuger.writeLine("(!)-- Failed to load image\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);;
                std::terminate();
            }
            textTex = SDL_CreateTextureFromSurface(ren, image);
            if(!textTex){
                debuger.writeLine("(!)-- SDL_CreateTextureFromSurface has failed cuased by bad args", ERRORS);
                std::terminate();
            }
            sprite_rec = rec;
            name = Name;
            tag = Tag;
            layer = Layer;
            textStringValue = str;
        }

        void change(const char * str, SDL_Color rgb, TTF_Font * font, SDL_Renderer * ren){
            if(!font)
            {
                debuger.writeLine("(!)-- Failed to load font\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_Surface* image = TTF_RenderText_Solid(font, str, rgb);
            if(!image)
            {
                debuger.writeLine("(!)-- Failed to load image\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);;
                std::terminate();
            }
            SDL_DestroyTexture(textTex);
            debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTE);
            textTex = SDL_CreateTextureFromSurface(ren, image);
            if(!textTex){
                debuger.writeLine("(!)-- SDL_CreateTextureFromSurface has failed cuased by bad args", ERRORS);
                std::terminate();
            }
            textStringValue = str;
        }

        void push(std::vector<text*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }
    private:
        std::vector<text*> * vector = nullptr;
};


// define all assets here like this: std::shared_ptr<Asset> ex;
//v
struct Assets {
    std::shared_ptr<Asset> apple;
    std::shared_ptr<Asset> belt;
};

Assets gAssets;
