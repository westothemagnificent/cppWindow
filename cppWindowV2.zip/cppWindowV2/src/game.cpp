#include "SDLWINDOW.hpp"
#include <iostream>
#include <string>
#include <vector>

WIN window;
SDL_Event event;
TTF_Font* Sans;


class Paiza : public gameObject{
    public:

        bool grabed = false;

        void click(int st, int t, button * self){
            if(t == 1){
                grabed = true;
            }
            else{
                grabed = false;
            }
        }
        
        button paizaButton = button([this](int st, int t, button * self){click(st, t, self);}, trect(0,0,50,50), trect(0,0,100,100), "paiza", "food", 2, gAssets.apple);

        void start(){
            gameObjectRec = trect(200,200,0,0);
            bindRec(&paizaButton.buttonRec);
            bindRec(&paizaButton.buttonSprite.sprite_rec);
        }

        void update(){
            tickAllBoundRecs();
            if(grabed){
                // paizaButton.buttonRec.x = window.mouseX;
                // paizaButton.buttonRec.y = window.mouseY;
                // paizaButton.buttonSprite.sprite_rec.y = window.mouseY;
                // paizaButton.buttonSprite.sprite_rec.x = window.mouseX;
                gameObjectRec.x = window.mouseX;
                gameObjectRec.y = window.mouseY;
            }
        }

        Paiza(){
            name = "paiza";
            pushGameObject(&window.gameObjectPointers);
            push(&window.scriptPointers);
            paizaButton.push(&window.buttonPointers, &window.spritePointers);
        }
};
    
class Belt : public gameObject{
    public:

        sprite beltSprite = sprite(trect(0,0,800,100), "belt", "belt", 1, gAssets.belt);


        void start(){
            bindRec(&beltSprite.sprite_rec);
            gameObjectRec = trect(800,400,0,0);
        }

        void update(){
            tickAllBoundRecs();
            std::vector<Paiza*> paizas = window.findGameObject<Paiza>("paiza");
            for(int i=0; i < paizas.size(); i++){
                paizas[i]->gameObjectRec.x += 1;
            }
        }

        Belt(){
            name = "belt";
            pushGameObject(&window.gameObjectPointers);
            push(&window.scriptPointers);
            beltSprite.push(&window.spritePointers);
            
        }

};



class CountDownText : public gameObject{
    public:

        text sprite = text(trect(window.CENTERX, window.width - window.CENTERY*1.4 ,300,100), "text", "ui", 1, "cooking... time left: ??",  {255,255,255}, Sans, window.ren);

        int timeLeft = 12000;

        bool color = false;
        int wiggleTime = 50;

        // script sc = script(&startBALL, &updateBALL, &window.scriptPointers);

        void start(){
            
        }

        void update(){
            
            if(timeLeft < 2000){
                wiggleTime -= 1;
            }
            if(wiggleTime < 0){
                if(color){
                    color = false;
                }
                else{
                    color = true;
                }
                wiggleTime = 50;
            }
            if(color){
                sprite.change(("cooking... time left: " + std::to_string(timeLeft)).c_str(), {255,255,255}, Sans, window.ren);    
            }
            else{
                sprite.change(("cooking... time left: " + std::to_string(timeLeft)).c_str(), {0,0,0}, Sans, window.ren);
            }
            
            timeLeft -= 1;

            if(timeLeft < 0){
                timeLeft = 0;
            }
            
        }

        CountDownText(){
            push(&window.scriptPointers);
            sprite.push(&window.textPointers);
        }
};



// ball





std::vector<sprite*> sprites = {};
std::vector<text*> texts = {};

std::vector<button*> buttons = {};


void closed(){
    
}

void start(){

    window.width = 1000;
    window.height = 600;
    window.open_window("some window");

    
    window.load_assets();
    if (TTF_Init() < 0) {
	    std::cout << "Error initializing SDL_ttf: " << TTF_GetError() << "\n";
    }
    Sans = TTF_OpenFont("fonts/static/OpenSans-Medium.ttf", 24);


    // buttons.push_back(new button([](int st, button * self){if(st == 1){std::cout<<"hello\n";}else if(st == 2){std::cout<<"hover\n";}}, trect(window.CENTERX,window.CENTERY,25,25), trect(window.CENTERX, window.CENTERY, 100,100), "button", "button", 1, gAssets.apple));
    // buttons[buttons.size()-1]->push(&window.buttonPointers, &window.spritePointers);

    // texts.push_back(new text(trect(window.CENTERX,window.CENTERY,300,100), "text", "ui", 1, "hello, this a screen saver",  {255,255,255}, Sans, window.ren));
    // texts[texts.size()-1]->push(&window.textPointers);

    // sprites.push_back(new sprite(trect(window.CENTERX, window.CENTERY,40,40), "ball", "gameObject", 1, gAssets.apple));
    // sprites[sprites.size()-1]->push(&window.spritePointers);
    new Paiza();

    new Belt();

    new CountDownText();

    //new gamePlayManger();
    //TEST::TEST();


    debuger.debug = true;
    debuger.level = ALL;

    bool isWindowOpen = true;

    while (isWindowOpen){
        
        // clear

        window.renClear();

        // window exit?

        SDL_PollEvent(&event);
        isWindowOpen = window.checkIfUserExitThenExit(event, &closed);

        // handle events

        window.handleEvents(event);



        // draw
        window.setBg(100,200,100);
        
        window.renderAllSprites();

        //show
        window.show();

        if(GetAsyncKeyState(VK_ESCAPE) & 0x01){
            for (size_t i = 0; i < window.spritePointers.size(); i++)
            {
                window.spritePointers[i]->deleteSprite();
            }
            
        }
    }

    std::cout << " exited!\n";

}



int main(int argc, char ** argv){
    start();
    return 0;
}