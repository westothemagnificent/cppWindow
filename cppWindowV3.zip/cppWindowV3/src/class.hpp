#include "SDL.h"
#include "SDL_ttf.h"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <windows.h>
#include <functional>
#include "Point.hpp"
#include "Assets.hpp"
#include "vec_ex_.hpp"


#define ALL 4
#define NONE -1
#define NOTES 0
#define WARNINGS 1
#define ERRORS 2
#define FATALERRORS 3

#pragma once

class {
    public:

        int errorLevel;

        template<typename T>
        void writeLine(T str){
            std::cout << str << "\n";
        }
        template<typename T>
        void write(T str){
            std::cout << str;
        }

        template<typename T>
        void writeLine(T str, int level){
            if(errorLevel == ALL || level < errorLevel){
                std::cout << str << "\n";
            }
        }
        template<typename T>
        void write(T str, int level){
            if(errorLevel == ALL || level < errorLevel){
                std::cout << str;
            }
        }


}debuger;

class script{
    public:

        std::string SCRIPTFLAG = "";

        std::string scriptName = "";

        void push(std::vector<script*> * vec){
            vec->push_back(this);

            start();
        }
        virtual void start(){
                
        }

        virtual void update(){
            
        }
};

class gameObject : public script{
    public:
        std::string gameObjectName;
        std::string gameObjectTag;

        trect gameObjectRec = trect(0,0,0,0);

        std::vector<trect*> boundRecs = {};
        std::vector<trect> startingPos = {};

        void bindRec(trect * rec){
            boundRecs.push_back(rec);
            startingPos.push_back(*rec);
        }

        void tickAllBoundRecs(){
            for (int i = 0; i < boundRecs.size(); i++){
                
                double offX = startingPos[i].x;
                double offY = startingPos[i].y;

                boundRecs[i]->x = gameObjectRec.x; 
                boundRecs[i]->y = gameObjectRec.y;
                
                boundRecs[i]->x += offX;
                boundRecs[i]->y += offY;
            }
            
        }


        void pushGameObject(std::vector<gameObject*> * vec){
            vec->push_back(this);
        }

};


class collider{
    
    public:
        
        trect rec = trect(0,0,0,0);
        bool sleeping = false;

        collider(trect recF, bool isSleeping){
            rec = recF;
            sleeping = isSleeping;
        }

        void pushCollider(std::vector<collider*> * vec){
            vec->push_back(this);
        }

};

class shader{
    public:
        std::function<void(Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a, int x, int y)> pixel;
        shader(std::function<void(Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a, int x, int y)> p){
            pixel = p;
        }
        void push(std::vector<shader*> * vec){
            vec->push_back(this);
        }
};

class pose{
    public:
        int spriteSheetIndex = 0;
        double waitTime = 0;

        std::string path;

        pose(int spriteSheetIndex, double waitTime, std::string path){
            pose::spriteSheetIndex = spriteSheetIndex;
            pose::waitTime = waitTime;
            pose::path = path;
        }

};

class sprite {
    public:
        std::shared_ptr<Asset> asset;

        trect sprite_rec = trect(0,0,0,0);
        trect partRec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;

        double rot = 0;
        
        sprite(trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a, SDL_Renderer* ren) {
            sprite_rec = rec;
            partRec.w = sprite_rec.w;
            partRec.h = sprite_rec.h;
            name = Name;
            tag = Tag;
            layer = Layer;

            if (a != nullptr) {
                // Create a new Asset and duplicate the texture
                asset = std::make_shared<Asset>();
                asset->texture = duplicateTexture(a->texture, ren);
            } else {
                asset = nullptr;
            }
        }

        void showAnimation(std::vector<pose> poses){

        }

        void rotate(double dir){
            rot += dir;
            if(rot > 360){
                rot = 0;
            }
        }

        void push(std::vector<sprite*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }


    private:
        std::vector<sprite*> * vector = nullptr;

};

class button {
    public:

        sprite buttonSprite = sprite(trect(0,0,0,0), "NULL", "NULL", -1, nullptr, nullptr);

        trect buttonRec = trect(0,0,0,0);
        // 0 no state, 1 pressed, 2 hovered
        int state = 0;
        int toggle = 0;
        std::function<void(int, int, button*)> callBack;

        button(std::function<void(int, int, button*)> fp, trect buttonRecF, trect rec, std::string Name, std::string Tag, int Layer, std::shared_ptr<Asset> a, SDL_Renderer * ren) : callBack(fp){
            callBack = fp;
            buttonRec = buttonRecF;

            buttonSprite = sprite(rec, Name, Tag, Layer, a, ren);

            buttonSprite.partRec.print();
            // buttonSprite.name = Name;
            // buttonSprite.tag = Tag;
            // buttonSprite.layer = Layer;
            // buttonSprite.asset = a;
        }

        void handle(SDL_Event e, SDL_Renderer * ren, int mouseX, int mouseY){
            // SDL_Rect rec = buttonRec.trectToSDLrect();
            // SDL_RenderDrawRect(ren, &rec);
            if((e.type == SDL_MOUSEBUTTONDOWN) && (((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 1;
                if(toggle == 0){
                    toggle = 1;
                }
                else{
                    toggle = 0;
                }
            }
            else if((((buttonRec.x + buttonRec.w) > mouseX) && ((buttonRec.x - buttonRec.w) < mouseX)) && (((buttonRec.y + buttonRec.h) > mouseY) && ((buttonRec.y - buttonRec.h) < mouseY))){
                state = 2;
            }
            else{
                state = 0;
            }
            callBack(state, toggle, this);
    
        }

        void push(std::vector<button*> * vec, std::vector<sprite*> * spriteVec){
            vec->push_back(this);
            buttonSprite.push(spriteVec);
            vector = vec;
        }

    private:
        std::vector<button*> * vector = nullptr;

};

class text{
    public:
        
        SDL_Texture * textTex;
        std::string textStringValue;

        trect sprite_rec = trect(0,0,0,0);
        int layer;
        std::string name;
        std::string tag;

        double rot = 0;

        text(trect rec, std::string Name, std::string Tag, int Layer, const char * str, SDL_Color rgb, TTF_Font * font, SDL_Renderer * ren){
            if(!font)
            {
                debuger.writeLine("(!)-- Failed to load font\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                std::terminate();
            }
            SDL_Surface* image = TTF_RenderText_Solid(font, str, rgb);
            if(!image)
            {
                debuger.writeLine("(!)-- Failed to load image\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                // std::cout << SDL_GetError() << "\n";
                // rec.print();
                std::terminate();
            }
            textTex = SDL_CreateTextureFromSurface(ren, image);
            if(!textTex){
                debuger.writeLine("(!)-- SDL_CreateTextureFromSurface has failed cuased by bad args", ERRORS);
                std::terminate();
            }
            sprite_rec = rec;
            name = Name;
            tag = Tag;
            layer = Layer;
            textStringValue = str;
        }

        void change(const char * str, SDL_Color rgb, TTF_Font * font, SDL_Renderer * ren){

            if(textStringValue != str){

                if(!font)
                {
                    debuger.writeLine("(!)-- Failed to load font\n", ERRORS);
                    debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
                    std::terminate();
                }
                SDL_Surface* image = TTF_RenderText_Solid(font, str, rgb);
                if(!image)
                {
                    debuger.writeLine("(!)-- Failed to load image\n", ERRORS);
                    debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);;
                    std::terminate();
                }
                SDL_DestroyTexture(textTex);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTES);
                textTex = SDL_CreateTextureFromSurface(ren, image);
                if(!textTex){
                    debuger.writeLine("(!)-- SDL_CreateTextureFromSurface has failed cuased by bad args", ERRORS);
                    std::terminate();
                }
                textStringValue = str;
            }
        }

        void rotate(double dir){
            rot += dir;
            if(rot > 360){
                rot = 0;
            }
        }

        void push(std::vector<text*> * vec){
            vec->push_back(this);
            vector = vec;
        }

        void deleteSprite(){
            tag = "DEL";
        }
    private:
        std::vector<text*> * vector = nullptr;
};


// define all assets here like this: std::shared_ptr<Asset> ex;
//v

