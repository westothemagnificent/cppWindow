#include "SDLWINDOW.hpp"
#include <iostream>
#include <string>
#include <vector>
#include "Query.hpp"
#include <psapi.h>
#include <sys/stat.h>
#include <chrono>
#include <thread>

WIN window;
SDL_Event event;
TTF_Font* Sans;

Uint64 NOW = 0;
Uint64 LAST = 0;
double deltaTime = 0.0;
double secondsPerCount = 0.0;

const double targetFrameTime = 1.0 / 60.0;

class confetti : public gameObject{
    public:

        double force = window.random(10, 50);

        double angle = (double(window.random(0,1000)) / 1000 * 1.570 + 0.785) + 3.14;

        point speed = point(cos(angle) * force, sin(angle) * force);

        double rotSpeed = window.random(-9,9);

        sprite confettiSprite = sprite(trect(0,0,50,60), "confetti", "sprite", 4, gAssets.confetti, window.ren);

        shader randShader = shader([this](Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a, int x, int y){
        
            *r = window.random(90,255);
            *g = window.random(90,255);
            *b = window.random(90,255);
            // *a = 128;

        });

        void start(){
            bindRec(&confettiSprite.sprite_rec);
            gameObjectRec = trect(window.CENTERX,window.height,0,0);

                        
            window.useShader(confettiSprite.asset->texture, &randShader);

            if(speed.x > 17){
                speed.x *= 0.8;
            }
            if(speed.x < -17){
                speed.x *= 0.8;
            }
        }

        void update(){
            
            gameObjectRec.x += speed.x;
            gameObjectRec.y += speed.y;

            speed.y += 0.5; 

            confettiSprite.rotate(rotSpeed);

            if(window.height+100 < gameObjectRec.y){
                confettiSprite.tag = "DEL";
            }

        }

        confetti(){
            confettiSprite.push(&window.spritePointers);

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "slpashScreen";
        }
};

class slpashScreen : public gameObject{
    public:

        text title = text(trect(0,0,200,100), "splashText", "text", 1, "celebrate!! <3",  {0,0,0}, Sans, window.ren);

        sprite TV = sprite(trect(window.CENTERX,window.CENTERY+5,500,600), "TV", "ui", 3, gAssets.TV, window.ren);
        point TVCenter = point(-35, 100);

        sprite TVScreen = sprite(trect(window.CENTERX + TVCenter.x - 20, window.CENTERY + TVCenter.y + 25,390,400), "TV", "ui", 1, gAssets.TVScreen, window.ren);

        point randPos = TVCenter;

        shader glitchShader = shader([](Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a, int x, int y){
            
            *r = window.random(0,255);
            *g = window.random(0,255);
            *b = window.random(0,255);
            // *a = 128;

        });

        bool TVGlitchAble = true;

        void playButtonClicked(int st, int t, button * self){
            if(st == 1){
                debuger.writeLine("starting");
                TV.tag = "ui";
                TVGlitchAble = false;
                point speed = point(0,-10);

                window.cam = TVCenter;

                for (int i = 0; i < 500; i++)
                {
                    new confetti();
                }
                window.resetLayers();

                playButton.buttonSprite.tag = "DEL";
                playButton.buttonRec = trect(0,0,0,0);

                std::thread thread_object([=](){
                    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
                    debuger.writeLine("happy b-day!!");
                    title.change("happy b-day!!", {0,0,0}, Sans, window.ren);

                    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
                    title.change("I love you <3", {0,0,0}, Sans, window.ren);

                    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
                    title.change("you are the best dad!", {0,0,0}, Sans, window.ren);

                    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
                    title.change("now patry!!!", {0,0,0}, Sans, window.ren);

                    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

                    for (size_t i = 0; i < 100; i++)
                    {
                        std::this_thread::sleep_for(std::chrono::milliseconds(1000));

                        for (int i = 0; i < 500; i++)
                        {
                            new confetti();
                        }
                        window.resetLayers();
                    }

                });

                thread_object.detach();
                
                // int time = 0;

                // taskHandler.addTask(new task("slpashScreenStart", 
                // [=]() mutable {
                    
                // }, 
                // [=]() mutable{
                //     // update

                //     time ++;
                // }, 
                // [=]() mutable -> bool{
                //     // is done
                //     if(time > 1000){
                //         debuger.writeLine("happ b-day!!");
                //         title.change("happy brith day!!", {0,0,0}, Sans, window.ren);
                //         return true;
                //     }
                //     else{
                //         return false;
                //     }
                
                // },
                // [=]() mutable {
                    
                // }   
                // ));
                
            }
        }

        button playButton = button([this](int st, int t, button * self){
            playButtonClicked(st, t, self);
        }, trect(-55,160,70,40), trect(0,100,70,40), "playButton", "button", 2, gAssets.apple, window.ren);


        void start(){
            bindRec(&title.sprite_rec);
            bindRec(&playButton.buttonSprite.sprite_rec);
            bindRec(&playButton.buttonRec);
            gameObjectRec = trect(window.CENTERX, window.CENTERY,0,0);
        }

        void update(){
            
            if(TVGlitchAble){
                window.cam.lerp(randPos, 5*deltaTime);

                if(window.random(1,150) == 1){
                    randPos = point(window.random(-500,500),window.random(-500,500));
                }

                if(window.cam.distance(TVCenter) > 40){
                    randPos = TVCenter;
                }
            }

            window.useShader(TVScreen.asset->texture, &glitchShader);
            //window.useShader(playButton2.buttonSprite.asset->texture, &glitchShader);

        }

        slpashScreen(){
            title.push(&window.textPointers);
            TV.push(&window.spritePointers);
            TVScreen.push(&window.spritePointers);
            playButton.push(&window.buttonPointers, &window.spritePointers);

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "slpashScreen";
        }
};

class devTool : public gameObject{
    public:
        
        SDL_Event * event;

        bool paused = false;

        bool devToolsOn = false;

        const int MoveSpeed = 100;

        text devToolsOnText = text(trect(window.CENTERX, 100, 200, 50), "devToolsOnText", "ui", 1, " ", {0,0,0}, Sans, window.ren);

        void start(){
            SCRIPTFLAG = "DONT_RUN";
        }

        void update(){

            if(devToolsOn == true){
                devToolsOnText.change("(*)-- dev tools are on.", {255,255,255}, Sans, window.ren);
            }
            else{
                devToolsOnText.change(" ", {255,255,255}, Sans, window.ren);
            }

            if(paused == true){
                window.runScripts = false;
            }
            else{
                window.runScripts = true;
            }

            if(event->key.keysym.sym == SDLK_INSERT && event->type == SDL_KEYDOWN){
                if(devToolsOn == true){
                    devToolsOn = false;
                    debuger.writeLine("(*)-- dev tools have been turned off");
                }
                else{
                    devToolsOn = true;
                    debuger.writeLine("(*)-- dev tools have been turned on");
                }
            }

            if(devToolsOn){
                // window.cam.print();
                if(event->key.keysym.sym == SDLK_TAB && event->type == SDL_KEYDOWN){
                    if(paused == true){
                        paused = false;
                        debuger.writeLine("(*)--  unpuased");
                    }
                    else{
                        paused = true;
                        debuger.writeLine("(*)-- puased");
                    }
                }
                
                if(event->key.keysym.sym == SDLK_LEFT && event->type == SDL_KEYDOWN){
                    window.cam.x -= MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_RIGHT && event->type == SDL_KEYDOWN){
                    window.cam.x += MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_UP && event->type == SDL_KEYDOWN){
                    window.cam.y -= MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_DOWN && event->type == SDL_KEYDOWN){
                    window.cam.y += MoveSpeed*deltaTime;
                }
                // switch(event->type){

                //     case SDL_KEYDOWN:
                //         switch(event->key.keysym.sym){
                //             case SDLK_LEFT:
                //                 window.cam.x -= 10*deltaTime;
                //                 break;
                //             case SDLK_RIGHT:
                //                 window.cam.x += 10*deltaTime;
                //                 break;
                //             case SDLK_UP:
                //                 window.cam.y -= 10*deltaTime;
                //                 break;
                //             case SDLK_DOWN:
                //                 window.cam.y += 10*deltaTime;
                //                 break;
                //         }
                // }
            }

        }

        devTool(SDL_Event * event){
            
            scriptName = "devTools";

            devTool::event = event;
            devToolsOnText.push(&window.textPointers);


            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
        }
};


void closed(){
    SDL_GL_DeleteContext(window.glContext);
    SDL_DestroyWindow(window.SDLWindow);
    SDL_Quit();
}

void start(){

    window.width = 1000;
    window.height = 600;
    window.open_window("some window");

    NOW = SDL_GetPerformanceCounter();
    secondsPerCount = 1.0 / static_cast<double>(SDL_GetPerformanceFrequency());

    
    window.load_assets();
    if (TTF_Init() < 0) {
	    std::cout << "Error initializing SDL_ttf: " << TTF_GetError() << "\n";
    }
    Sans = TTF_OpenFont("fonts/static/OpenSans-Medium.ttf", 24);


    // buttons.push_back(new button([](int st, button * self){if(st == 1){std::cout<<"hello\n";}else if(st == 2){std::cout<<"hover\n";}}, trect(window.CENTERX,window.CENTERY,25,25), trect(window.CENTERX, window.CENTERY, 100,100), "button", "button", 1, gAssets.apple));
    // buttons[buttons.size()-1]->push(&window.buttonPointers, &window.spritePointers);

    // texts.push_back(new text(trect(window.CENTERX,window.CENTERY,300,100), "text", "ui", 1, "hello, this a screen saver",  {255,255,255}, Sans, window.ren));
    // texts[texts.size()-1]->push(&window.textPointers);

    // sprites.push_back(new sprite(trect(window.CENTERX, window.CENTERY,40,40), "ball", "gameObject", 1, gAssets.apple));
    // sprites[sprites.size()-1]->push(&window.spritePointers);

    //new gamePlayManger();

    new slpashScreen();

    devTool * devTools = new devTool(&event);
    
    window.resetLayers();

    debuger.errorLevel = NONE;

    bool isWindowOpen = true;

    while (isWindowOpen){
        

        
        LAST = NOW;
        NOW = SDL_GetPerformanceCounter();

        deltaTime = static_cast<double>(NOW - LAST) * secondsPerCount;

        if (deltaTime < targetFrameTime) {
            int delayTime = static_cast<int>((targetFrameTime - deltaTime) * 1000.0);
            SDL_Delay(delayTime);
        }

        NOW = SDL_GetPerformanceCounter();
        deltaTime = static_cast<double>(NOW - LAST) * secondsPerCount;

        // clear

        window.renClear();

        // window exit?

        SDL_PollEvent(&event);
        isWindowOpen = window.checkIfUserExitThenExit(event, &closed);

        // handle events

        window.handleEvents(event);

        // devToolsTick

        devTools->update();
        taskHandler.updateAll();



        // draw
        window.setBg(100,100,100);
        
        window.renderAllSprites();

        //show
        window.show();

    }

    std::cout << " exited!\n";

}



int main(int argc, char ** argv){
    start();
    return 0;
}