#include "SDL.h"
#include "SDL_ttf.h"
#include <memory>
#include <cstdio>

#pragma once

struct Asset {
    SDL_Texture * texture;
};

struct Assets {
    std::shared_ptr<Asset> apple;
    std::shared_ptr<Asset> TV;
    std::shared_ptr<Asset> TVScreen;
    std::shared_ptr<Asset> confetti;
    std::shared_ptr<Asset> payButton;
    std::shared_ptr<Asset> NULLTEX;
};

SDL_Texture* duplicateTexture(SDL_Texture* originalTexture, SDL_Renderer* renderer) {
    int textureWidth, textureHeight;
    SDL_QueryTexture(originalTexture, NULL, NULL, &textureWidth, &textureHeight);

    // Query the pixel format of the original texture
    Uint32 format;
    SDL_QueryTexture(originalTexture, &format, NULL, NULL, NULL);

    // Create streaming texture with the same format
    SDL_Texture* duplicatedTexture = SDL_CreateTexture(renderer, format, SDL_TEXTUREACCESS_STREAMING, textureWidth, textureHeight);
    if (!duplicatedTexture) {
        printf("Failed to create duplicated texture: %s\n", SDL_GetError());
        return nullptr;
    }

    // Lock the original texture to access the pixel data
    void* originalPixels;
    int originalPitch;
    if (SDL_LockTexture(originalTexture, NULL, &originalPixels, &originalPitch) != 0) {
        printf("Failed to lock original texture: %s\n", SDL_GetError());
        SDL_DestroyTexture(duplicatedTexture);
        return nullptr;
    }

    // Lock the duplicated texture to write pixel data
    void* duplicatedPixels;
    int duplicatedPitch;
    if (SDL_LockTexture(duplicatedTexture, NULL, &duplicatedPixels, &duplicatedPitch) != 0) {
        printf("Failed to lock duplicated texture: %s\n", SDL_GetError());
        SDL_UnlockTexture(originalTexture);
        SDL_DestroyTexture(duplicatedTexture);
        return nullptr;
    }

    // Copy pixel data from original texture to duplicated texture
    Uint8* src = static_cast<Uint8*>(originalPixels);
    Uint8* dst = static_cast<Uint8*>(duplicatedPixels);
    for (int y = 0; y < textureHeight; ++y) {
        memcpy(dst + y * duplicatedPitch, src + y * originalPitch, textureWidth * SDL_BYTESPERPIXEL(format));
    }

    // Unlock textures
    SDL_UnlockTexture(originalTexture);
    SDL_UnlockTexture(duplicatedTexture);

    return duplicatedTexture;
}

Assets gAssets;
