#include "SDL.h"
#include "SDL_ttf.h"
#include "SDL_audio.h"
#include "SDL_syswm.h"
#include "class.hpp"
#include "Query.hpp"


#include <iostream>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
// #include <windows.h>
#include <functional>
#include <optional>
// #include <bits/stdc++.h>
#include <algorithm>
#include <SDL_opengl.h>
//#include "SDL2_image.h"

#define AUDIO_FREQUENCY 44100
#define AUDIO_FORMAT AUDIO_S16LSB
#define AUDIO_CHANNELS 2
#define AUDIO_CHUNKSIZE 4096


#pragma once  // If supported by compiler

class task{
    public:
        std::function<void()> update;
        std::function<void()> start;
        std::function<bool()> done;
        std::function<void()> callWhenDone;

        std::string name;

        bool hasRun = false;

        task(std::string inputName, std::function<void()> startFunc, std::function<void()> updateFunc, std::function<bool()> doneFunc, std::function<void()> callWhenDoneFunc){
            name = inputName;
            update = updateFunc;
            start = startFunc;
            done = doneFunc;
            callWhenDone = callWhenDoneFunc;
        }


};

class {
    public:

        std::vector<task*> tasks = {};

        void addTask(task* inputTask){
            tasks.push_back(inputTask);
        }

        void updateAll(){
            for(int i=0; i<tasks.size(); i++){
                if(tasks[i]->hasRun == true){
                    bool isDone = tasks[i]->done();
                    if(isDone == false){
                        tasks[i]->update();
                    }
                    else{
                        tasks[i]->callWhenDone();
                        std::cout << "(*)-- Task " << tasks[i]->name << " is done" << "\n";
                        tasks.erase(tasks.begin() + i);
                    }
                }
                else{
                    tasks[i]->start();
                    tasks[i]->hasRun = true;
                }
            }
        }

        void stopTask(std::string name){

            for (int i=0; i < tasks.size(); i++){
                if(tasks[i]->name == name){
                    std::cout << "(*)-- Task " << tasks[i]->name << "was stoped" << "\n";
                    tasks.erase(tasks.begin() + i);
                }
            }
            
        }



}taskHandler;

class WIN {
    public:
        SDL_Window * SDLWindow;
        SDL_Renderer * ren;

        SDL_GLContext glContext = nullptr;

        std::vector<sprite*> spritePointers = {};
        std::vector<text*> textPointers = {};

        std::vector<button*> buttonPointers = {};

        std::vector<script*> scriptPointers = {};
        std::vector<gameObject*> gameObjectPointers = {};
        std::vector<shader*> shadersPointers = {};

        point cam = point(0,0);

        // editing this will cuase sprite using these to change positions
        int CENTERX;
        // editing this will cuase sprite using these to change positions
        int CENTERY;

        // do NOT change after calling open window
        int width;
        // do NOT change after calling open window
        int height;

        int mouseX;
        int mouseY;

        bool runScripts = true;

        // window stuff
        void open_window(const char * name) {
            if (SDL_Init(SDL_INIT_EVERYTHING)) {
                debuger.writeLine("(!)-- Failed to initialize the SDL2 library\n", ERRORS);
                debuger.writeLine("(!)-- SDL2 Error: \n" + std::string(SDL_GetError()), ERRORS);
                std::terminate();
            }
            SDL_Window * windowSDL = SDL_CreateWindow(
                name,
                SDL_WINDOWPOS_CENTERED,
                SDL_WINDOWPOS_CENTERED,
                width,
                height,
                //SDL_WINDOW_ALWAYS_ON_TOP
                SDL_WINDOW_RESIZABLE
            );
            CENTERX = width / 2;
            CENTERY = height / 2;
            SDLWindow = windowSDL;
            ren = SDL_CreateRenderer(SDLWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
            int doubleBuffering;
            SDL_GL_GetAttribute(SDL_GL_DOUBLEBUFFER, &doubleBuffering);
            SDL_SetHint("SDL_HINT_RENDER_SCALE_QUALITY", "linear");
            SDL_RenderSetLogicalSize(ren, width, height);
            SDL_RaiseWindow(SDLWindow);
            SDL_SetWindowInputFocus(SDLWindow);
            glContext = SDL_GL_CreateContext(SDLWindow);
            SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
        }

        void setFullScreen(){
            SDL_SetWindowFullscreen(SDLWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
        }
        void resizeWindow(SDL_Window * window, int w, int h){
            width = w;
            height = h;
            CENTERX = width / 2;
            CENTERY = height / 2;
            SDL_SetWindowSize(window, w, h);
        }
        
        //drawing

        void render_sprite(sprite sprite, int index) {
            if (sprite.tag == "ui") {
                sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2));
                sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2));

                // sprite.partRec.x = ((sprite.partRec.x - sprite.partRec.w / 2));
                // sprite.partRec.y = ((sprite.partRec.y - sprite.partRec.h / 2));
            }
            else{
                sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2)+cam.x);
                sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2)+cam.y);

                // sprite.partRec.x = sprite.sprite_rec.x;
                // sprite.partRec.y = sprite.sprite_rec.y;
            }
            // sprite.partRec.print();
            // debuger.writeLine("^^^ partRec");
            // sprite.sprite_rec.print();
            // debuger.writeLine("^^^ sprite_rec");
            if (nullptr != sprite.asset) {
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();
                SDL_Rect pRec = sprite.partRec.trectToSDLrect();


                SDL_Point center = {sprite.sprite_rec.w/2, sprite.sprite_rec.h/2};
                

                //SDL_RenderCopy(ren, sprite.asset->texture, NULL, &rec)

                SDL_SetTextureBlendMode(sprite.asset->texture, SDL_BLENDMODE_BLEND); 
                SDL_RenderCopyEx(ren, sprite.asset->texture, &pRec, &rec, sprite.rot, &center, SDL_FLIP_NONE);
                //debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopyEx(ren, sprite.asset->texture, &pRec, &rec, sprite.rot, &center, SDL_FLIP_NONE))), NOTES);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(spritePointers[index]->asset->texture);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTES);

                spritePointers.erase(spritePointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNINGS);
            }
        }

        void render_text(text sprite, int index) {
            if (nullptr != sprite.textTex) {
                if (sprite.tag == "ui") {
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2));
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2));
                }
                else{
                    sprite.sprite_rec.x = ((sprite.sprite_rec.x - sprite.sprite_rec.w / 2)+cam.x);
                    sprite.sprite_rec.y = ((sprite.sprite_rec.y - sprite.sprite_rec.h / 2)+cam.y);
                }
                SDL_Rect rec = sprite.sprite_rec.trectToSDLrect();

                SDL_Point center = {sprite.sprite_rec.w/2, sprite.sprite_rec.h/2};


                SDL_RenderCopyEx(ren, sprite.textTex, NULL, &rec, sprite.rot, &center, SDL_FLIP_NONE);
                //debuger.writeLine("(*)-- SDL_RenderCopy fine 0 / error -1 code: " + std::string(std::to_string(SDL_RenderCopyEx(ren, sprite.textTex, NULL, &rec, sprite.rot, &center, SDL_FLIP_NONE))), NOTES);
            }
            else if(sprite.tag != "DEL"){
                debuger.writeLine("(!)-- error sprite: " + sprite.name + " has no asset! \n", ERRORS);
                std::terminate();
            }
            if(sprite.tag == "DEL"){
                // at this point a do not care FIX LATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER
                SDL_DestroyTexture(textPointers[index]->textTex);
                debuger.writeLine("(*)-- SDL_DestroyTexture code: " + std::string(SDL_GetError()), NOTES);

                textPointers.erase(textPointers.begin() + index);
                debuger.writeLine("(!?)--  sprite has been deleted", WARNINGS);
            }
        }

        void resetLayers(){
            std::vector<int> layers = {};
            std::vector<sprite*> buffer = {};
            for (int i = 0; i < spritePointers.size(); i++)
            {
                layers.push_back(spritePointers[i]->layer);
            }
            int r = 0;
            if(spritePointers.size() > 0){
                r = *std::max_element(layers.begin(), layers.end());
            }
            debuger.writeLine(r);
            // debuger.writeLine("No layer to reset", NOTES);
            for (int i = 0; i < r; i++)
            {   
                for(int o=0; o < layers.size(); o++){
                    if(layers.size() >= i){
                        if(i == layers[o]-1){
                            buffer.push_back(spritePointers[o]);
                        }
                    }
                }
            }
            spritePointers = buffer;
            debuger.writeLine(spritePointers.size());
        }

        void renderAllSprites() {
            // std::vector<layer> vecL = {};

            for (size_t i = 0; i < spritePointers.size(); i++) {
                render_sprite(*spritePointers[i], i);
            }
            
            for (size_t i = 0; i < textPointers.size(); i++) {
                render_text(*textPointers[i], i);
            }
        }

        void useShader(SDL_Texture* texture, shader * sh) {
            int textureWidth, textureHeight;
            SDL_QueryTexture(texture, nullptr, nullptr, &textureWidth, &textureHeight);

            // Lock texture for writing
            void* texturePixels;
            int pitch;
            if (SDL_LockTexture(texture, nullptr, &texturePixels, &pitch) != 0) {
                std::cerr << "Failed to lock texture: " << SDL_GetError() << std::endl;
                return; // Handle error gracefully
            }

            // Access the pixel data
            Uint32* pixels = static_cast<Uint32*>(texturePixels);
            int pixelCount = textureWidth * textureHeight;

            // Manipulate pixels (example: invert colors)

            for(int x=0; x<textureWidth; x++){
                for(int y=0; y<textureHeight; y++){
                    Uint8* pixel = reinterpret_cast<Uint8*>(&pixels[x+y*textureWidth]);
                    sh->pixel(&pixel[3], &pixel[2], &pixel[1], &pixel[0], (double)x/(double)textureWidth, (double)y/(double)textureHeight);
                }
            }
            // Unlock texture
            SDL_UnlockTexture(texture);
        }


        // do NOT set rgb value over 255
        void setBg(int r, int g, int b){
            SDL_SetRenderDrawColor(ren, r, g, b, 0);
        }

        void renClear(){
            SDL_RenderClear(ren);
        }

        void show(){
            SDL_RenderPresent(ren);
        }

        // event handling

        bool checkIfUserExitThenExit(SDL_Event e, void (*callBack)()) {
            bool r = true;
            switch (e.type) {
                case SDL_QUIT:
                    debuger.writeLine("(*)-- SDL closed", NOTES);
                    callBack();
                    r = false;
                    break;
            }
            return r;
        }

        void handleEvents(SDL_Event e){
            SDL_GetMouseState(&mouseX,&mouseY);
            for(int i=0; i < gameObjectPointers.size(); i++){
                gameObjectPointers[i]->tickAllBoundRecs();
            }
            for(int i=0; i < buttonPointers.size(); i++){
                button buttonTar = (*buttonPointers[i]);
                buttonPointers[i]->handle(e,ren,mouseX,mouseY);
                if (buttonPointers[i]->buttonSprite.tag == "ui") {
                    buttonTar.buttonRec.x = ((buttonTar.buttonRec.x - buttonTar.buttonRec.w / 2));
                    buttonTar.buttonRec.y = ((buttonTar.buttonRec.y - buttonTar.buttonRec.h / 2));
                }
                else{
                    buttonTar.buttonRec.x = ((buttonTar.buttonRec.x - buttonTar.buttonRec.w / 2)+cam.x);
                    buttonTar.buttonRec.y = ((buttonTar.buttonRec.y - buttonTar.buttonRec.h / 2)+cam.y);
                }
            }
            if(runScripts == true){
                for(int i=0; i < scriptPointers.size(); i++){
                    if(scriptPointers[i]->SCRIPTFLAG != "DONT_RUN"){
                        scriptPointers[i]->update();
                    }
                }
            }
        }

        int random(int min, int max) {
            int r = rand()%(max-min + 1) + min;
            return r;
        }

        // searching functions

        template <typename T>
        
        std::vector<T*> findGameObject(std::string name){
            std::vector<T*> vec = {};
            for (size_t i = 0; i < gameObjectPointers.size(); i++)
            {
                if(gameObjectPointers[i]->gameObjectName == name){
                    
                    T * r = dynamic_cast<T*>(gameObjectPointers[i]);
                    if(r == nullptr){
                        debuger.writeLine("(!)-- could not cast", ERRORS);
                        std::terminate();
                    }
                    else{
                        vec.push_back(r);
                    }
                }
            }

            if(vec.size() == 0){
                debuger.writeLine("(!?)-- could not find game object", WARNINGS);
            }

            return vec;
            
        }

        template <typename T, typename I>

        T castTo(I input){
            T r = dynamic_cast<T>(input);
            if(r == nullptr){
                debuger.writeLine("(!?)-- could not cast", WARNINGS);
            }
            else{
                return r;
            }
            return nullptr;
        }

        script * findScript(std::string name){
            for (size_t i = 0; i < scriptPointers.size(); i++)
            {
                if(scriptPointers[i]->scriptName == name){
                    return scriptPointers[i];
                }
            }
            
        }

        // audio

        int calculateWavDuration(Uint32 wavLength, SDL_AudioSpec *wavSpec) {
            int bytes_per_sample = SDL_AUDIO_BITSIZE(wavSpec->format) / 8;
            int channels = wavSpec->channels;
            int freq = wavSpec->freq;

            int duration_ms = (wavLength / bytes_per_sample / channels) / (freq / 1000);

            return duration_ms;
        }

        void playSound(std::shared_ptr<Sound> sound){

            SDL_AudioDeviceID deviceId = SDL_OpenAudioDevice(NULL, 0, &sound->wav_spec, NULL, 0);
            if (deviceId == 0) {
                debuger.writeLine("(!)-- can not play sound", ERROR);
            }

            SDL_QueueAudio(deviceId, sound->wav_start, sound->wav_length);
            SDL_PauseAudioDevice(deviceId, 0); // Start playing audio

            std::thread thread_object([=](){
                // Adjust time to play the sound (in milliseconds)
                debuger.writeLine("starting...");
                int duration_ms = calculateWavDuration(sound->wav_length, &sound->wav_spec);
                std::this_thread::sleep_for(std::chrono::milliseconds(duration_ms));
                debuger.writeLine("done!");

                SDL_CloseAudioDevice(deviceId);
            });

            thread_object.detach();

        }

        // file stuff

    std::shared_ptr<Sound> load_sound(const char * file){
        std::shared_ptr<Sound> sound = std::make_shared<Sound>();

        /* Load the WAV */
        if (SDL_LoadWAV(file, &sound->wav_spec, &sound->wav_start, &sound->wav_length) == NULL) {
            debuger.writeLine("(!)-- can not load sound", ERROR);
            std::terminate();
        } 
        else {

        }

        sound->wav_spec.freq = AUDIO_FREQUENCY;
        sound->wav_spec.format = AUDIO_FORMAT;
        sound->wav_spec.channels = AUDIO_CHANNELS;
        sound->wav_spec.samples = AUDIO_CHUNKSIZE;
        sound->wav_spec.callback = NULL; // No callback needed
        sound->wav_spec.userdata = NULL;

        return sound;
    }

    void load_sounds(){
        gSounds.TEST = load_sound("sound/yippe.wav");
    }

    SDL_Surface* textureToSurface(SDL_Renderer* renderer, SDL_Texture* texture) {
        if (!renderer) {
            std::cerr << "Renderer is NULL" << std::endl;
            return nullptr;
        }
        if (!texture) {
            std::cerr << "Texture is NULL" << std::endl;
            return nullptr;
        }

        int width, height;
        Uint32 format;
        if (SDL_QueryTexture(texture, &format, nullptr, &width, &height) != 0) {
            std::cerr << "SDL_QueryTexture failed: " << SDL_GetError() << std::endl;
            return nullptr;
        }

        // Create an SDL_Surface with a compatible format
        SDL_Surface* surface = SDL_CreateRGBSurface(0, width, height, 32,
                                                    0x00FF0000,
                                                    0x0000FF00,
                                                    0x000000FF,
                                                    0xFF000000);
        if (!surface) {
            std::cerr << "SDL_CreateRGBSurface() failed: " << SDL_GetError() << std::endl;
            return nullptr;
        }

        // Read pixels from the texture to the surface
        if (SDL_SetRenderTarget(renderer, texture) != 0) {
            std::cerr << "SDL_SetRenderTarget() failed: " << SDL_GetError() << std::endl;
            SDL_FreeSurface(surface);
            return nullptr;
        }

        if (SDL_RenderReadPixels(renderer, nullptr, surface->format->format, surface->pixels, surface->pitch) != 0) {
            std::cerr << "SDL_RenderReadPixels() failed: " << SDL_GetError() << std::endl;
            SDL_FreeSurface(surface);
            SDL_SetRenderTarget(renderer, nullptr);
            return nullptr;
        }

        SDL_SetRenderTarget(renderer, nullptr);

        return surface;
    }


    std::shared_ptr<Asset> load_asset(const char * file) {
        std::shared_ptr<Asset> asset = std::make_shared<Asset>();

        // Load BMP file into a surface
        SDL_Surface * suf = SDL_LoadBMP(file);
        if (!suf) {
            debuger.writeLine("(!)-- Failed to load file: " + std::string(file) + "\n", ERRORS);
            debuger.writeLine("(!)-- SDL2 Error: " + std::string(SDL_GetError()) + "\n", ERRORS);
            std::terminate();
        }

        // Optionally, convert surface format if needed
        SDL_Surface* optimizedSurface = SDL_ConvertSurfaceFormat(suf, SDL_PIXELFORMAT_RGBA8888, 0);
                if (!optimizedSurface) {
                    std::cerr << "Failed to convert surface format: " << SDL_GetError() << std::endl;
                    SDL_FreeSurface(suf);
                    std::terminate();
                }

                // Create texture with streaming access
                // when SDL_IMAGE is installed....
                // SDL_PIXELFORMAT_UNKNOWN
                SDL_Texture* texture = SDL_CreateTexture(ren,SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STREAMING,
                                                        optimizedSurface->w, optimizedSurface->h);
                if (!texture) {
                    std::cerr << "Failed to create texture: " << SDL_GetError() << std::endl;
                    SDL_FreeSurface(optimizedSurface);
                    SDL_FreeSurface(suf);
                    std::terminate();
                }

                // Lock texture for writing
                void* texturePixels;
                int pitch;
                if (SDL_LockTexture(texture, nullptr, &texturePixels, &pitch) != 0) {
                    std::cerr << "Failed to lock texture: " << SDL_GetError() << std::endl;
                    SDL_DestroyTexture(texture);
                    SDL_FreeSurface(optimizedSurface);
                    SDL_FreeSurface(suf);
                    std::terminate();
                }

                // Copy pixels from surface to texture
                memcpy(texturePixels, optimizedSurface->pixels, optimizedSurface->pitch * optimizedSurface->h);

                // Unlock texture
                SDL_UnlockTexture(texture);

                // Assign the created texture to asset
                asset->texture = texture;

                // Clean up surfaces
                SDL_FreeSurface(optimizedSurface);
                SDL_FreeSurface(suf);

                return asset;
        }

        //gAssets.ex = load_asset("art/ex.bmp"); load all of your assets here
        //v
        void load_assets() {
            gAssets.apple = load_asset("art/apple.bmp");
            gAssets.TV = load_asset("art/TV.bmp");
            gAssets.TVScreen = load_asset("art/TVSrceen.bmp");
            gAssets.confetti = load_asset("art/confetti.bmp");
            gAssets.NULLTEX = load_asset("art/NULLTEX.bmp");
            gAssets.payButton = load_asset("art/payNow.bmp");
        }
};

