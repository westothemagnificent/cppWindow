#include "window.hpp"
#include <iostream>
#include <string>
#include <vector>
// #include <psapi.h>
#include <sys/stat.h>
#include <chrono>
#include <thread>

// shader includes

#include "shaders/redShader.hpp"


// gameObjects includes

#include "gameObjects/fireWorkParticles.hpp"
#include "gameObjects/fireWork.hpp"
#include "gameObjects/fireWorkCluster.hpp"
#include "gameObjects/launch.hpp"
#include "gameObjects/devTool.hpp"


void closed(){
    SDL_GL_DeleteContext(window.glContext);
    SDL_DestroyWindow(window.SDLWindow);
    SDL_Quit();
}

void start(){

    window.width = 1300;
    window.height = 700;
    window.open_window("some window");

    // SDL_SetWindowOpacity(window.SDLWindow, 0.3);
    // SDL_SetWindowBordered(window.SDLWindow, SDL_FALSE);

    NOW = SDL_GetPerformanceCounter();
    secondsPerCount = 1.0 / static_cast<double>(SDL_GetPerformanceFrequency());

    
    window.load_assets();
    window.load_sounds();
    if (TTF_Init() < 0) {
	    std::cout << "Error initializing SDL_ttf: " << TTF_GetError() << "\n";
    }
    Sans = TTF_OpenFont("fonts/static/OpenSans-Medium.ttf", 24);


    // buttons.push_back(new button([](int st, button * self){if(st == 1){std::cout<<"hello\n";}else if(st == 2){std::cout<<"hover\n";}}, trect(window.CENTERX,window.CENTERY,25,25), trect(window.CENTERX, window.CENTERY, 100,100), "button", "button", 1, gAssets.apple));
    // buttons[buttons.size()-1]->push(&window.buttonPointers, &window.spritePointers);

    // texts.push_back(new text(trect(window.CENTERX,window.CENTERY,300,100), "text", "ui", 1, "hello, this a screen saver",  {255,255,255}, Sans, window.ren));
    // texts[texts.size()-1]->push(&window.textPointers);

    // sprites.push_back(new sprite(trect(window.CENTERX, window.CENTERY,40,40), "ball", "gameObject", 1, gAssets.apple));
    // sprites[sprites.size()-1]->push(&window.spritePointers);

    //new gamePlayManger();

    new launch(&event);

    devTool * devTools = new devTool(&event);
    
    window.resetLayers();

    debuger.errorLevel = NONE;

    bool isWindowOpen = true;

    while (isWindowOpen){
        

        
        LAST = NOW;
        NOW = SDL_GetPerformanceCounter();

        deltaTime = static_cast<double>(NOW - LAST) * secondsPerCount;

        if (deltaTime < targetFrameTime) {
            int delayTime = static_cast<int>((targetFrameTime - deltaTime) * 1000.0);
            SDL_Delay(delayTime);
        }

        NOW = SDL_GetPerformanceCounter();
        deltaTime = static_cast<double>(NOW - LAST) * secondsPerCount;

        // clear

        window.renClear();

        // window exit?

        SDL_PollEvent(&event);
        isWindowOpen = window.checkIfUserExitThenExit(event, &closed);

        // handle events

        window.handleEvents(event);

        // devToolsTick

        devTools->update();
        taskHandler.updateAll();



        // draw
        window.setBg(30,20,30);
        
        window.renderAllSprites();

        //show
        window.show();

    }

    std::cout << " exited!\n";

}



int main(int argc, char ** argv){
    start();
    return 0;
}