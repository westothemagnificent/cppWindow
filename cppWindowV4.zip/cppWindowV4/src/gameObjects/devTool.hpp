#include "../window.hpp"

#pragma once



class devTool : public gameObject{
    public:
        
        SDL_Event * event;

        bool paused = false;

        bool devToolsOn = false;

        const int MoveSpeed = 100;

        text devToolsOnText = text(trect(window.CENTERX, 100, 200, 50), "devToolsOnText", "ui", 1, " ", {0,0,0}, Sans, window.ren);

        void start(){
            SCRIPTFLAG = "DONT_RUN";
        }

        void update(){

            if(devToolsOn == true){
                devToolsOnText.change("(*)-- dev tools are on.", {255,255,255}, Sans, window.ren);
            }
            else{
                devToolsOnText.change(" ", {255,255,255}, Sans, window.ren);
            }

            if(paused == true){
                window.runScripts = false;
            }
            else{
                window.runScripts = true;
            }

            if(event->key.keysym.sym == SDLK_INSERT && event->type == SDL_KEYDOWN){
                if(devToolsOn == true){
                    devToolsOn = false;
                    debuger.writeLine("(*)-- dev tools have been turned off");
                }
                else{
                    devToolsOn = true;
                    debuger.writeLine("(*)-- dev tools have been turned on");
                }
            }

            if(devToolsOn){
                // window.cam.print();
                if(event->key.keysym.sym == SDLK_TAB && event->type == SDL_KEYDOWN){
                    if(paused == true){
                        paused = false;
                        debuger.writeLine("(*)--  unpuased");
                    }
                    else{
                        paused = true;
                        debuger.writeLine("(*)-- puased");
                    }
                }
                
                if(event->key.keysym.sym == SDLK_LEFT && event->type == SDL_KEYDOWN){
                    window.cam.x -= MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_RIGHT && event->type == SDL_KEYDOWN){
                    window.cam.x += MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_UP && event->type == SDL_KEYDOWN){
                    window.cam.y -= MoveSpeed*deltaTime;
                }
                if(event->key.keysym.sym == SDLK_DOWN && event->type == SDL_KEYDOWN){
                    window.cam.y += MoveSpeed*deltaTime;
                }
                // switch(event->type){

                //     case SDL_KEYDOWN:
                //         switch(event->key.keysym.sym){
                //             case SDLK_LEFT:
                //                 window.cam.x -= 10*deltaTime;
                //                 break;
                //             case SDLK_RIGHT:
                //                 window.cam.x += 10*deltaTime;
                //                 break;
                //             case SDLK_UP:
                //                 window.cam.y -= 10*deltaTime;
                //                 break;
                //             case SDLK_DOWN:
                //                 window.cam.y += 10*deltaTime;
                //                 break;
                //         }
                // }
            }

        }

        devTool(SDL_Event * event){
            
            scriptName = "devTools";

            devTool::event = event;
            devToolsOnText.push(&window.textPointers);


            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
        }
};