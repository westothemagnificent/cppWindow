#include "../window.hpp"
#include "fireWorkParticles.hpp"

#pragma once 

class fireWork: public gameObject{
    public:
    
        bool done = false;

        point speed = point(window.random(-2,2), window.random(-20,-25));

        double rotSpeed = window.random(-9,9);

        sprite fireWorkSprite = sprite(trect(0,0,window.random(40, 50),window.random(40, 50)), "fireWorkSprite", "sprite", 1, gAssets.apple, window.ren);

        int a = 0;

        void start(){
            bindRec(&fireWorkSprite.sprite_rec);
            gameObjectRec = trect(window.random(100, window.width-100),window.height,50,50);

            // if(speed.x > 17){
            //     speed.x *= 0.8;
            // }
            // if(speed.x < -17){
            //     speed.x *= 0.8;
            // }

        }

        void update(){
            
            gameObjectRec.x += speed.x;
            gameObjectRec.y += speed.y;

            speed.y += 0.4;

            fireWorkSprite.rotate(rotSpeed);

            if(window.height+100 < gameObjectRec.y){
                fireWorkSprite.tag = "DEL";
            }

            if(speed.y > -10 && done == false && window.random(1, 10) == 1){
                for (int i = 0; i < a; i++)
                {
                    new fireWorkParticles(gameObjectRec.x, gameObjectRec.y);
                }
                window.playSound(gSounds.TEST);

                fireWorkSprite.tag = "DEL";

                done = true;
            }

        }

        fireWork(int a){
            fireWorkSprite.push(&window.spritePointers);

            fireWork::a = a;

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "fireWork";
        }
};