#include "../window.hpp"
#include "fireWork.hpp"
#include "fireWorkParticles.hpp"

#pragma once 


class fireWorkCluster: public gameObject{
    public:
    
        bool done = false;

        point speed = point(window.random(-2,2), window.random(-20,-25));

        double rotSpeed = window.random(-9,9);

        sprite fireWorkSprite = sprite(trect(0,0,window.random(60, 65),window.random(60, 65)), "fireWorkClusterSprite", "sprite", 1, gAssets.apple, window.ren);

        void start(){
            bindRec(&fireWorkSprite.sprite_rec);
            gameObjectRec = trect(window.random(100, window.width-100),window.height,50,50);

            // if(speed.x > 17){
            //     speed.x *= 0.8;
            // }
            // if(speed.x < -17){
            //     speed.x *= 0.8;
            // }

        }

        void update(){
            
            gameObjectRec.x += speed.x;
            gameObjectRec.y += speed.y;

            speed.y += 0.4;

            fireWorkSprite.rotate(rotSpeed);

            if(window.height+100 < gameObjectRec.y){
                fireWorkSprite.tag = "DEL";
            }

            if(speed.y > 0 && done == false && window.random(1, 10) == 1){
                for (int i = 0; i < 200; i++)
                {
                    new fireWorkParticles(gameObjectRec.x, gameObjectRec.y);
                }

                for (int i = 0; i < 4; i++)
                {
                    fireWork * FireWork = new fireWork(100);

                    FireWork->gameObjectRec = gameObjectRec;
                    if(i == 1){
                        FireWork->speed.x = 10;
                        FireWork->speed.y = 0;
                    }
                    if(i == 2){
                        FireWork->speed.x = -10;
                        FireWork->speed.y = 0;
                    }
                    if(i == 3){
                        FireWork->speed.x = 0;
                        FireWork->speed.y = -10;
                    }
                    if(i == 2){
                        FireWork->speed.x = 0;
                        FireWork->speed.y = 10;
                    }
                }
                
                window.playSound(gSounds.TEST);

                fireWorkSprite.tag = "DEL";

                done = true;
            }

        }

        fireWorkCluster(){
            fireWorkSprite.push(&window.spritePointers);

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "fireWorkCluster";
        }
};  