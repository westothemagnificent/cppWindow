#include "../window.hpp"

#pragma once 

class fireWorkParticles: public gameObject{
    public:


        double force = window.random(1, 20);

        double angle = (double(window.random(0,1000)) / 1000 * (1.570*4) + 0.785) + 3.14;

        point speed = point(cos(angle) * force, sin(angle) * force);

        double rotSpeed = window.random(-9,9);

        sprite fireWorkParticleSprite = sprite(trect(0,0,window.random(10, 20),window.random(20, 30)), "fireWorkParticle", "sprite", 4, gAssets.confetti, window.ren);

        void start(){
            bindRec(&fireWorkParticleSprite.sprite_rec);


            if(speed.x > 17){
                speed.x *= 0.8;
            }
            if(speed.x < -17){
                speed.x *= 0.8;
            }

        }

        void update(){
            
            gameObjectRec.x += speed.x;
            gameObjectRec.y += speed.y;

            speed.y += 0.5; 

            fireWorkParticleSprite.rotate(rotSpeed);

            if(window.height+100 < gameObjectRec.y){
                fireWorkParticleSprite.tag = "DEL";
            }

        }

        fireWorkParticles(int x, int y){
            gameObjectRec = trect(x,y,50,50);
            fireWorkParticleSprite.push(&window.spritePointers);

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "fireWorkParticle";

                                    
            window.useShader(fireWorkParticleSprite.asset->texture, &redShader);
        }
};