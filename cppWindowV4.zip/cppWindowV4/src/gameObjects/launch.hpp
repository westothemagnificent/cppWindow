#include "../window.hpp"
#include "fireWork.hpp"
#include "fireWorkParticles.hpp"
#include "fireWorkCluster.hpp"

#pragma once 

class launch : public gameObject{
    public:

        SDL_Event * event = nullptr;

        bool started = false;

        void ButtonClicked(int st, int t, button * self){
            if(st == 1){
                
                started = true;
                
            }
        }

        button Button = button([this](int st, int t, button * self){
            ButtonClicked(st, t, self);
        }, trect(-55,160,70,40), trect(0,140,70,40), "launch", "button", 2, gAssets.payButton, window.ren);


        void start(){
            bindRec(&Button.buttonSprite.sprite_rec);
            bindRec(&Button.buttonRec);
            gameObjectRec = trect(window.CENTERX, window.CENTERY,1000,100);

        }

        void update(){
            if(started){
                Button.buttonSprite.sprite_rec = trect(0,0,0,0);
            }
            if(started == true && window.random(1, 40) == 1){
                if(window.random(1, 3) == 1){
                    new fireWorkCluster();
                }
                else{
                    new fireWork(500);
                }
            }   
        }

        launch(SDL_Event * e){
            Button.push(&window.buttonPointers, &window.spritePointers);

            push(&window.scriptPointers);
            pushGameObject(&window.gameObjectPointers);
            gameObjectName = "slpashScreen";

            event = e;
        }
};