#include "../window.hpp"

#pragma once 

shader redShader = shader([](Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a, int x, int y){
        
            *r = 255;
            *g = 0;
            *b = 255;
            // *a = 128;

});