#include "SDL.h"
#include "SDL_ttf.h"
#include "SDL_audio.h"
#include <memory>
#include <string>
#include <vector>

struct Sound{
    SDL_AudioSpec wav_spec;
    Uint32 wav_length;
    Uint8 *wav_start;
    Uint8 *wav_buffer;
};

struct sounds{
    std::shared_ptr<Sound> TEST;
};

sounds gSounds;