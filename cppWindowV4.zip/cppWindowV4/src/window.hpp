#include "SDLWINDOW.hpp"

#pragma once

SDL_Event event;
TTF_Font* Sans;

Uint64 NOW = 0;
Uint64 LAST = 0;
double deltaTime = 0.0;
double secondsPerCount = 0.0;

const double targetFrameTime = 1.0 / 60.0;


WIN window;